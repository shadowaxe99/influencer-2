
import React from "react";

const AgentProfile = () => {
    return (
        <div className="agent-profile">
            <h3>Meet Our Agents</h3>
            {/* Detailed profiles of each agent */}
        </div>
    );
};
export default AgentProfile;
